export interface Environment {
    production: boolean,
    allmoviesurl: string
}