import { Environment } from './environment.interface';

export const environment: Environment = {
  production: true,
  allmoviesurl: "http://starlord.hackerearth.com/movies"
};