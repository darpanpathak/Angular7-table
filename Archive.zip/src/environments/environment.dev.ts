import { Environment } from './environment.interface';

export const environment: Environment = {
  production: false,
  allmoviesurl: "../../public/data/movies.json"
}